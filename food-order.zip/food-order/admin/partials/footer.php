<div class="footer">
        <div class="wrapper">
            <p class="text-center">2021 All rights reserved, food ordering restaurant.</p>
        </div>
    </div>
</body>

</html>